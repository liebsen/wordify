-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `beliefs`;
CREATE TABLE `beliefs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refocus_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `text` longtext COLLATE utf8_unicode_ci,
  `is_opposite` tinyint(1) DEFAULT '0',
  `is_selected` tinyint(1) DEFAULT NULL,
  `is_core` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7727DBF233606D13` (`refocus_id`),
  CONSTRAINT `beliefs_fk_refocus` FOREIGN KEY (`refocus_id`) REFERENCES `refocuses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `beliefs` (`id`, `refocus_id`, `parent_id`, `text`, `is_opposite`, `is_selected`, `is_core`, `created`, `updated`) VALUES
(1,	NULL,	0,	'ss',	0,	0,	0,	'2018-08-19 16:03:35',	'2018-08-19 16:03:35'),
(2,	NULL,	0,	's',	0,	0,	0,	'2018-08-19 16:04:19',	'2018-08-19 16:04:19'),
(3,	NULL,	0,	'dd',	0,	0,	0,	'2018-08-19 16:05:18',	'2018-08-19 16:05:18'),
(4,	NULL,	0,	'sdasd',	0,	0,	0,	'2018-08-19 16:06:08',	'2018-08-19 16:06:08'),
(5,	NULL,	0,	'asdasd',	0,	0,	0,	'2018-08-19 16:11:23',	'2018-08-19 16:11:23'),
(6,	11,	0,	'asdasd',	0,	0,	0,	'2018-08-19 16:14:45',	'2018-08-19 16:14:45'),
(7,	12,	0,	'asdasd',	0,	0,	0,	'2018-08-19 16:14:57',	'2018-08-19 16:14:57'),
(8,	14,	0,	'sdfsdf',	0,	0,	0,	'2018-08-19 16:41:49',	'2018-08-19 16:41:49'),
(9,	14,	0,	'dfgdfg',	0,	0,	0,	'2018-08-19 16:42:00',	'2018-08-19 16:42:00'),
(10,	14,	0,	'asdasd',	0,	0,	0,	'2018-08-19 16:47:56',	'2018-08-19 16:47:56'),
(11,	14,	0,	'sdfsdfsdf',	0,	0,	0,	'2018-08-20 11:06:41',	'2018-08-20 11:06:41');

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `config_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Setting Key',
  `config_value` longtext COLLATE utf8_unicode_ci COMMENT 'Setting Value',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `config` (`id`, `config_key`, `config_value`, `created`, `updated`) VALUES
(1,	'APP_TITLE',	'ReFocus',	'2018-08-14 12:13:03',	'2018-08-14 12:13:03'),
(2,	'APP_SLOGAN',	'Moving Forward',	'2018-08-14 12:14:27',	'2018-08-14 12:14:27'),
(3,	'APP_AUTHOR',	'TBOC, Creative Team',	'2018-08-14 15:26:07',	'2018-08-14 15:26:07'),
(4,	'APP_KEYWORDS',	'refocus, reframe, reframing, rethink, thinking outside the box, out of the box thinking, out of the box, outside the box, Karim, Karim Benammar, the art of thinking differently, different perspective, creative problem solving',	'2018-08-14 15:26:36',	'2018-08-14 15:26:36'),
(5,	'APP_SUBTITLE',	'Helps you to think differently',	'2018-08-14 15:26:56',	'2018-08-14 15:26:56'),
(6,	'APP_DESC',	'Reframing is an easy and free online tool that helps you to find creative approaches for life and work. It&rsquo;s fun, try it now!',	'2018-08-14 15:27:05',	'2018-08-14 15:27:05'),
(7,	'MAIL_FROM_FNAME',	'No Reply',	'2018-08-14 15:27:35',	'2018-08-14 15:27:35'),
(8,	'MAIL_FROM_NAME',	'The Blue Ocean Company',	'2018-08-14 15:27:48',	'2018-08-14 15:27:48'),
(9,	'MAIL_SMTP_ACCOUNT',	'devmetasoft@gmail.com',	'2018-08-14 15:27:57',	'2018-08-14 15:27:57'),
(10,	'MAIL_SMTP_PASSWORD',	'Zoala090!',	'2018-08-14 15:28:05',	'2018-08-14 15:28:05'),
(11,	'MAIL_SMTP_HOST',	'smtp.gmail.com',	'2018-08-14 15:28:19',	'2018-08-14 15:28:19'),
(12,	'MAIL_SMTP_AUTH',	'true',	'2018-08-14 15:28:31',	'2018-08-14 15:28:31'),
(13,	'MAIL_SMTP_SECURE',	'ssl',	'2018-08-14 15:28:39',	'2018-08-14 15:28:39'),
(14,	'MAIL_SMTP_DEBUG',	'0',	'2018-08-14 15:28:46',	'2018-08-14 15:28:46'),
(15,	'MAIL_SMTP_PORT',	'465',	'2018-08-14 15:28:53',	'2018-08-14 15:28:53'),
(16,	'APP_HASH_SALT',	'e65db503460ac059b394cd8cb1be37bb',	'2018-08-15 11:21:15',	'2018-08-15 11:21:15'),
(17,	'APP_JWT_SECRET',	'b3957be059bdb0346564cd8cb1be30ac',	'2018-08-15 11:21:56',	'2018-08-15 11:21:56'),
(18,	'APP_JWT_EXPIRATION',	'50 hours',	'2018-08-15 11:22:11',	'2018-08-15 11:22:11'),
(19,	'APP_IMAGE_UPLOAD_MAX',	'3000',	'2018-08-15 11:22:48',	'2018-08-15 11:22:48'),
(20,	'APP_IMAGE_EXTENSION',	'jpg',	'2018-08-15 11:23:00',	'2018-08-15 11:23:00'),
(21,	'APP_IMAGE_QUALITY',	'90',	'2018-08-15 11:23:12',	'2018-08-15 11:23:12'),
(22,	'APP_IMAGE_UPLOAD_EXT',	'jpeg,jpg,png,gif',	'2018-08-15 11:23:24',	'2018-08-15 11:23:24'),
(23,	'APP_IMAGE_POST',	'200x200,500x375,800x600',	'2018-08-15 11:23:59',	'2018-08-15 11:23:59'),
(24,	'APP_IMAGE_USER',	'80x80,200x200',	'2018-08-15 11:24:10',	'2018-08-15 11:24:10'),
(25,	'REFOCUS_INST_STEP1',	'[\"What are you struggling with? <br>Start with the words \\u201cI can’t ...\\u201c\",\"What core belief would you like to change?\"]',	'2018-08-16 18:02:27',	'2018-08-16 18:02:27'),
(26,	'REFOCUS_INST_STEP2',	'[\"What reasons can you think of that support your core belief? List four of them.\", \"Why do you believe that \\u201c{{ core_belief }}\\u201d?\"]',	'2018-08-16 18:02:41',	'2018-08-16 18:02:41');

DROP TABLE IF EXISTS `movies`;
CREATE TABLE `movies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_slug` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `intro` longtext COLLATE utf8_unicode_ci,
  `pic1_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content_html` longtext COLLATE utf8_unicode_ci,
  `from_datetime` datetime DEFAULT NULL,
  `to_datetime` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `movies` (`id`, `title`, `title_slug`, `intro`, `pic1_url`, `youtube`, `content_html`, `from_datetime`, `to_datetime`, `deleted`, `enabled`, `created`, `updated`) VALUES
(1,	'Refocus',	'refocus',	'Intro refocuses',	NULL,	NULL,	'content refocuses',	NULL,	NULL,	0,	1,	'2018-08-17 14:21:23',	'2018-08-17 14:21:23');

DROP TABLE IF EXISTS `movies_map`;
CREATE TABLE `movies_map` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `movie_id` int(10) unsigned DEFAULT '0',
  `parent_id` int(10) unsigned DEFAULT '0',
  `map_key` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `map_value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `wizards_map_wizard_id` (`movie_id`),
  KEY `wizards_map_parent_id` (`parent_id`),
  CONSTRAINT `movies_map_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `movies_map` (`id`, `movie_id`, `parent_id`, `map_key`, `map_value`) VALUES
(1,	1,	0,	'chapter',	'Explanation'),
(2,	1,	1,	'ins',	'Explanation A'),
(3,	1,	1,	'ins',	'Explanation B'),
(4,	1,	1,	'html',	'<span>Explanation text</span>'),
(5,	1,	0,	'chapter',	'Find Core'),
(6,	1,	5,	'belief',	'core'),
(7,	1,	5,	'ins',	'Find your Core Belief  In your life!!!'),
(8,	1,	5,	'ins',	'What are you keeping from move forward?'),
(9,	1,	5,	'info',	'<h4>Some options...</h4>\r\n<ul><li>Option 1</li><li>Option Two</li>'),
(10,	1,	5,	'scene',	'Find Core (Support 1)'),
(11,	1,	10,	'belief',	'support'),
(12,	1,	5,	'scene',	'Find Core (Support 2)'),
(13,	1,	12,	'belief',	'support'),
(14,	1,	5,	'scene',	'Find Core (Support 3)'),
(15,	1,	14,	'belief',	'support'),
(16,	1,	5,	'scene',	'Find Core (Support 4)'),
(17,	1,	16,	'belief',	'support');

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `parent_id` int(10) unsigned DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Title',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Slug',
  `intro` longtext COLLATE utf8_unicode_ci COMMENT 'Excerpt',
  `content_html` longtext COLLATE utf8_unicode_ci COMMENT 'Body',
  `pic1_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Main image',
  `button_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Action description',
  `button_label` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Action button text',
  `button_icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Action icon (fontawesome.com)',
  `button_link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Action URL',
  `is_navitem` tinyint(1) DEFAULT '0',
  `heroclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Aditional section classes',
  `enabled` tinyint(1) DEFAULT '1',
  `created` datetime DEFAULT '2018-08-20 16:41:45',
  `updated` datetime DEFAULT '2018-08-20 16:41:45',
  PRIMARY KEY (`id`),
  KEY `IDX_2074E575727ACA70` (`parent_id`),
  CONSTRAINT `theme_sections_fk_section` FOREIGN KEY (`parent_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Pages';

INSERT INTO `pages` (`parent_id`, `id`, `title`, `slug`, `intro`, `content_html`, `pic1_url`, `button_text`, `button_label`, `button_icon`, `button_link`, `is_navitem`, `heroclass`, `enabled`, `created`, `updated`) VALUES
(NULL,	1,	'Home',	'/',	'The main standard on the web.',	'<p>¿Qué es Lorem Ipsum?<br><br>Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creación de las hojas \"Letraset\", las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.<br><br>¿Por qué lo usamos?<br><br>Es un hecho establecido hace demasiado tiempo que un lector se distraerá con el contenido del texto de un sitio mientras que mira su diseño. El punto de usar Lorem Ipsum es que tiene una distribución más o menos normal de las letras, al contrario de usar textos como por ejemplo \"Contenido aquí, contenido aquí\". Estos textos hacen parecerlo un español que se puede leer. Muchos paquetes de autoedición y editores de páginas web usan el Lorem Ipsum como su texto por defecto, y al hacer una búsqueda de \"Lorem Ipsum\" va a dar por resultado muchos sitios web que usan este texto si se encuentran en estado de desarrollo. Muchas versiones han evolucionado a través de los años, algunas veces por accidente, otras veces a propósito (por ejemplo insertándole humor y cosas por el estilo).<br><br></p>',	NULL,	'Dive into the abyss to know what you need to know.',	'Refocus Now',	'rocket',	'/wizard/refocus/1',	1,	'is-info',	1,	'2018-08-14 18:43:32',	'2018-08-14 18:43:32'),
(NULL,	2,	'About',	'/about',	NULL,	'<p>¿Qué es Lorem Ipsum?<br><br>Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creación de las hojas \"Letraset\", las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.<br><br>¿Por qué lo usamos?<br><br>Es un hecho establecido hace demasiado tiempo que un lector se distraerá con el contenido del texto de un sitio mientras que mira su diseño. El punto de usar Lorem Ipsum es que tiene una distribución más o menos normal de las letras, al contrario de usar textos como por ejemplo \"Contenido aquí, contenido aquí\". Estos textos hacen parecerlo un español que se puede leer. Muchos paquetes de autoedición y editores de páginas web usan el Lorem Ipsum como su texto por defecto, y al hacer una búsqueda de \"Lorem Ipsum\" va a dar por resultado muchos sitios web que usan este texto si se encuentran en estado de desarrollo. Muchas versiones han evolucionado a través de los años, algunas veces por accidente, otras veces a propósito (por ejemplo insertándole humor y cosas por el estilo).<br><br></p>',	NULL,	NULL,	NULL,	NULL,	NULL,	1,	'is-success',	1,	'2018-08-14 18:44:20',	'2018-08-14 18:44:20'),
(NULL,	3,	'Site policy',	'/tos',	'sdf',	'<p>sdfsdf<br></p>',	'http://mercedesbenz.static/uploads/5b78a20c02fe0.jpeg',	NULL,	NULL,	NULL,	NULL,	0,	NULL,	1,	'2018-08-18 15:31:03',	'2018-08-18 15:31:03');

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `section_id` int(10) unsigned DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_slug` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `intro` longtext COLLATE utf8_unicode_ci,
  `button_link` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `button_value` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic1_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic2_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic3_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic4_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic5_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic6_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picshare_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `background_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content_html` longtext COLLATE utf8_unicode_ci,
  `from_datetime` datetime DEFAULT NULL,
  `to_datetime` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_section_id` (`section_id`),
  CONSTRAINT `posts_fk_section` FOREIGN KEY (`section_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `refocuses`;
CREATE TABLE `refocuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guid` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `putinhall` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refocuses_user_id` (`user_id`),
  CONSTRAINT `refocuses_fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `refocuses` (`id`, `user_id`, `title`, `guid`, `putinhall`, `created`, `updated`) VALUES
(1,	NULL,	NULL,	'c394a9c6-d34d-493-db16dd328829fa067',	0,	'2018-08-19 16:03:32',	'2018-08-19 16:03:32'),
(2,	NULL,	NULL,	'82be6bd2-17c3-30d-132996c0572e96f2e',	0,	'2018-08-19 16:04:15',	'2018-08-19 16:04:15'),
(3,	NULL,	NULL,	'ece858b5-8bb0-b33-d75ae2ed3bc9f3843',	0,	'2018-08-19 16:05:03',	'2018-08-19 16:05:03'),
(4,	NULL,	NULL,	'b443d2a9-5dfd-b21-04012e0c91338b595',	0,	'2018-08-19 16:05:47',	'2018-08-19 16:05:47'),
(5,	NULL,	NULL,	'e716b076-3dd6-7f4-40fe69fb0e443c1b4',	0,	'2018-08-19 16:06:04',	'2018-08-19 16:06:04'),
(6,	NULL,	NULL,	'916379b8-8c2a-413-efb58471ff0161865',	0,	'2018-08-19 16:11:02',	'2018-08-19 16:11:02'),
(7,	NULL,	NULL,	'932db6ba-d3a7-5d4-26e66051664faab47',	0,	'2018-08-19 16:11:17',	'2018-08-19 16:11:17'),
(8,	NULL,	NULL,	'b8d7ef61-504d-346-f2def5ecf90397303',	0,	'2018-08-19 16:13:34',	'2018-08-19 16:13:34'),
(9,	NULL,	NULL,	'0bb1ebc8-5ebb-a0b-6f57fb3c2d6fd4209',	0,	'2018-08-19 16:13:37',	'2018-08-19 16:13:37'),
(10,	NULL,	NULL,	'fb88af05-218e-848-0e2145f25480bc053',	0,	'2018-08-19 16:14:19',	'2018-08-19 16:14:19'),
(11,	NULL,	NULL,	'6f187874-ad9f-0fc-faed768a4dc0f2762',	0,	'2018-08-19 16:14:42',	'2018-08-19 16:14:42'),
(12,	NULL,	NULL,	'dff8a06c-075a-d6f-0b8e02c713b7429a3',	0,	'2018-08-19 16:14:55',	'2018-08-19 16:14:55'),
(13,	NULL,	NULL,	'4c3ae7bb-827c-224-2f8dd060c6cbfc05e',	0,	'2018-08-19 16:25:26',	'2018-08-19 16:25:26'),
(14,	NULL,	NULL,	'250237bf-7814-f58-f0e937927b9b81c11',	0,	'2018-08-19 16:41:45',	'2018-08-19 16:41:45'),
(15,	NULL,	NULL,	'b7367a65-98bb-40d-e0881cc7d1ded4f09',	0,	'2018-08-20 11:06:54',	'2018-08-20 11:06:54'),
(16,	NULL,	NULL,	'1db6696a-f685-63c-b72437907fa7b230b',	0,	'2018-08-20 11:49:50',	'2018-08-20 11:49:50');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `role_id` int(10) unsigned DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cc_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cc_exp_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cc_entity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cc_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locality` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `administrative_area_level_1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `administrative_area_level_2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `formatted_address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vicinity` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `map_icon` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `map_url` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `utc` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lat` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lng` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tone` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dnicuit` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` longtext COLLATE utf8_unicode_ci,
  `facebook_id` decimal(21,0) DEFAULT NULL,
  `google_id` decimal(21,0) DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'https://static.sectorseguro.com/img/placeholder.png',
  `background` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `newsletter` tinyint(1) DEFAULT NULL,
  `terms` tinyint(1) DEFAULT NULL,
  `as_ranking` int(10) unsigned DEFAULT '99',
  `as_gestion` int(10) unsigned DEFAULT NULL,
  `validated` tinyint(1) DEFAULT NULL,
  `last_activity` int(10) unsigned DEFAULT NULL,
  `online` tinyint(1) DEFAULT NULL,
  `anonymous` tinyint(1) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email` (`email`),
  UNIQUE KEY `users_username` (`username`),
  UNIQUE KEY `users_facebook_id` (`facebook_id`),
  UNIQUE KEY `users_google_id` (`google_id`),
  KEY `users_role_id` (`role_id`),
  CONSTRAINT `users_fk_role` FOREIGN KEY (`role_id`) REFERENCES `users_roles` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE `users_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- 2018-08-20 16:52:20
